package com.example.myfilmsaplication;

import android.content.Context;import android.view.LayoutInflater;
import android.view.View;import android.view.ViewGroup;
import android.widget.ArrayAdapter;import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;import androidx.annotation.Nullable;

public class AdapterH extends ArrayAdapter<item> {
    Context context;
    item [] arr;


    public AdapterH(Context context, item[] arr){
        super(context,R.layout.item,arr);
        this.context = context;
        this.arr = arr;
    }

    @NonNull    @Override

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE );

        View view = inflater.inflate(R.layout.item,parent,false);
        TextView name = (TextView) view.findViewById(R.id.textViewName);
        name.setText(arr[position].getName());
        TextView genre = (TextView) view.findViewById(R.id.textViewGenre);
        genre.setText(arr[position].getGenre());
        ImageView image = (ImageView) view.findViewById(R.id.imageViewFilm);
        image.setImageResource(R.drawable.ic_launcher_foreground);
        return view;
    }
}
