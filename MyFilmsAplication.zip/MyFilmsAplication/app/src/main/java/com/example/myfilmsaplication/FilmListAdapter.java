package com.example.myfilmsaplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FilmListAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<item> filmList;

    public FilmListAdapter(Context context, int layout, ArrayList<item> filmList) {
        this.context = context;
        this.layout = layout;
        this.filmList = filmList;
    }

    @Override
    public int getCount() {
        return filmList.size();
    }

    @Override
    public Object getItem(int position) {
        return filmList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        ImageView imageView;
        TextView txtName;
        TextView txtGenre;
        TextView txtYear;
        TextView txtTop;


    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        ViewHolder holder = new ViewHolder();
        if (row == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout,null);

            holder.txtName = (TextView) row.findViewById(R.id.textViewName);
            holder.txtGenre = (TextView) row.findViewById(R.id.textViewGenre);
            holder.txtYear = (TextView) row.findViewById(R.id.textViewYear);
            holder.txtTop = (TextView) row.findViewById(R.id.textViewIsItTop);
            row.setTag(holder);
        }

        return row;
    }
}
