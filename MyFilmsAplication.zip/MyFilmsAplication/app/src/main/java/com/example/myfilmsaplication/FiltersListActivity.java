package com.example.myfilmsaplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

public class FiltersListActivity extends AppCompatActivity {
    private Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filters_list);
        try {


            item[] arr = {new item("Name", "Genre","Year","Limit","Top"), new item("Name", "Genre","Year","Limit","Top"),};
            ListView lv = (ListView) findViewById(R.id.lv6);
            AdapterH adp = new AdapterH(this, arr);
            lv.setAdapter(adp);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
                    startActivity(intent);
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }

        back = (Button) findViewById(R.id.buttonBackToListF);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActvity2();
            }
        });
    }
    public void openActvity2(){
        Intent intent = new Intent(this, ListActivity.class);
        startActivity(intent);
    }

}