package com.example.myfilmsaplication;

public class FILMS {
    private int id;
    private String genre;
    private String name;
    private String year;
    private String limit;
    private String about;
    private byte[] image;


    public FILMS(String genre, String name, String year, String limit, String about, byte[] image, int id){
        this.genre = genre;
        this.name = name;
        this.year = year;
        this.limit = limit;
        this.about = about;
        this.image = image;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getLimit() {
        return limit;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}
