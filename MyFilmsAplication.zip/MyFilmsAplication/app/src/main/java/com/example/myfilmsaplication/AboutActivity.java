package com.example.myfilmsaplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;

public class AboutActivity extends AppCompatActivity {
    private SQLiteDatabase mData;

    private ImageView imageView;
    private Button back;
    private SQLite sqLite;
    private SQLiteDatabase database;


    @SuppressLint("WrongThread")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);


        try {


            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);

            imageView = findViewById(R.id.imageViewRead);





        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            back = (Button) findViewById(R.id.buttonBAckToListA);
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openListActivity();
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    private void openListActivity() {
        Intent intent = new Intent(this, ListActivity.class);
        startActivity(intent);
    }

}