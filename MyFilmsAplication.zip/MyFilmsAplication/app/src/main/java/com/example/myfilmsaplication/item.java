package com.example.myfilmsaplication;

public class item {
    String name;
    String genre;
    String year;
    String limit;
    String top;

    public item(String name,String genre,String year, String limit, String top){
        this.name = name;
        this.genre = genre;
        this.year = year;
        this.limit = limit;
        this.top = top;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getGenre(){
        return genre;
    }

    public void setGenre(String genre){
        this.genre = genre;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getLimit() {
        return limit;
    }


    public void setLimit(String limit) {
        this.limit = limit;
    }

    public String getTop() {
        return top;
    }

    public void setTop(String top) {
        this.top = top;
    }

}
