package com.example.myfilmsaplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogInActivity extends AppCompatActivity {
    private Button backToLogIn;
    private Button logInDone;
    private EditText editTextMail;
    private EditText editTextPass;
    private EditText editTextRepPass;
    SQLite sqLite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        editTextMail = (EditText) findViewById(R.id.editTextMailL);
        editTextPass = (EditText) findViewById(R.id.editTextPassL);
        editTextRepPass = (EditText) findViewById(R.id.editTextRepPass);

        sqLite = new SQLite(this, "FilmsDB.sqlite", null, 1);

        EditText EditTextPassL =(EditText)findViewById(R.id.editTextPassL);
        EditTextPassL.setHintTextColor(Color.WHITE);

        EditText EditTextMailL =(EditText)findViewById(R.id.editTextMailL);
        EditTextMailL.setHintTextColor(Color.WHITE);

        EditText EditTextRepPass =(EditText)findViewById(R.id.editTextRepPass);
        EditTextRepPass.setHintTextColor(Color.WHITE);

        logInDone = (Button) findViewById(R.id.buttonLogInL);
        logInDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mail = editTextMail.getText().toString();
                String pass = editTextPass.getText().toString();
                String repass = editTextRepPass.getText().toString();

                if (mail.equals(" ")||pass.equals(" ")||repass.equals(" ")){
                    Toast.makeText(LogInActivity.this,"Pleas enter all the fields", Toast.LENGTH_SHORT).show();
                }else {
                    if(pass.equals(repass)){
                        Boolean checkUser = sqLite.checkMail(mail);
                        if(checkUser ==false){
                            Boolean insert = sqLite.insertData(mail,pass);
                            if (insert == true){
                                Toast.makeText(LogInActivity.this,"Registered successfully",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),AdminActivity.class);
                                startActivity(intent);
                            }else {
                                Toast.makeText(LogInActivity.this,"Registration failed",Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            Toast.makeText(LogInActivity.this,"User already exists! Pleas log in",Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(LogInActivity.this,"Password is not matching",Toast.LENGTH_SHORT).show();
                    }
                }

                openAdminActivity();
            }
        });

        backToLogIn = (Button) findViewById(R.id.buttonBackToStartL);
        backToLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAdminActivity();
            }
        });
    }
    public void openAdminActivity(){
        Intent intent = new Intent(this,AdminActivity.class);
        startActivity(intent);
    }
}