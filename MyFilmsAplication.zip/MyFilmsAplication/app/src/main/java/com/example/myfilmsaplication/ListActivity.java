package com.example.myfilmsaplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    private Button top;
    private Button filters;
    private Button backToStart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        item [] arr = {new item("Name", "Genre","Year","Limit","Top"), new item("Name", "Genre","Year","Limit","Top")};
        ListView lv = (ListView) findViewById(R.id.listList);
        AdapterH adp = new AdapterH(this,arr);
        lv.setAdapter(adp);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
                startActivity(intent);
            }


        });




        filters = (Button) findViewById(R.id.buttonFilters);
        filters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTopActivity();
            }
        });

        top = (Button) findViewById(R.id.buttonTop);
        top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFiltersActvity();
            }
        });

        backToStart = (Button) findViewById(R.id.buttonBackToStart);
        backToStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStartActivity();
            }
        });
    }
    public void openFiltersActvity(){
        Intent intent = new Intent(this, FiltersActivity.class);
        startActivity(intent);
    }
    public void openTopActivity(){
        Intent intent = new Intent(this, TopActivity.class);
        startActivity(intent);
    }
    public void openStartActivity(){
        Intent intent = new Intent(this,StartActivity.class);
        startActivity(intent);
    }





}