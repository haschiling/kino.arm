package com.example.myfilmsaplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

public class SQLite  extends SQLiteOpenHelper {

    public static final String DBNAME = "Login.db";


    public SQLite(Context context, String name, SQLiteDatabase.CursorFactory factory, int i){
        super(context, "Login.db", factory, 1);
    }

    public void QueryData(String sql){
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }

    public void InsertData(String name, String genre, String year, String limit, String about, byte[] image ){
        SQLiteDatabase database = getWritableDatabase();
        String SQL = "INSERT INTO FILM VALUES (NULL, ?, ?, ?)";
        SQLiteStatement statement = database.compileStatement(SQL);
        statement.clearBindings();
        statement.bindString(1, name);
        statement.bindString(2, genre);
        statement.bindString(3, year);
        statement.bindString(4, limit);
        statement.bindString(5, about);
        statement.bindBlob(6, image);
    }

    public Cursor getData(String sql){
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create Table users(mail TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("drop Table if exists users");

    }



    public Boolean insertData(String mail, String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("mail",mail);
        contentValues.put("password", password);
        long result = sqLiteDatabase.insert("users", null, contentValues);
        if(result == -1){
            return false;
        }else {
            return true;
        }

    }
     public Boolean checkMail(String mail){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from users where mail = ?",new String[]{mail});
        if(cursor.getCount() > 0){
            return true;
        }else {
            return false;
        }
     }
     public Boolean checkPassword(String mail, String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from users where mail = ? and password = ?", new String[]{mail,password});
        if(cursor.getCount() > 0){
            return true;
        }else {
            return false;
        }
     }

    public void insertData(String Name, String Genre, String Data, String Limit, String About, byte[] imageViewToByte) {
    }
}
