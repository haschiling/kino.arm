package com.example.myfilmsaplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminActivity extends AppCompatActivity {
    private Button BackToStart;
    private Button login;
    private Button signin;
    private EditText yourMail;
    private EditText yourPass;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        SQLite sqLite = new SQLite(this, "FilmsDB.sqlite", null, 1);

        EditText EditTextLogIn =(EditText)findViewById(R.id.editTextLogIn);
        EditTextLogIn.setHintTextColor(Color.WHITE);

        EditText EditTextPass =(EditText)findViewById(R.id.editTextTextPassword);
        EditTextPass.setHintTextColor(Color.WHITE);

        yourMail = (EditText) findViewById(R.id.editTextLogIn);
        yourPass = (EditText) findViewById(R.id.editTextTextPassword);

        signin = (Button) findViewById(R.id.buttonSignIn);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = yourMail.getText().toString();
                String pass = yourPass.getText().toString();

                if(user.equals(" ") || pass.equals(" ")){
                    Toast.makeText(AdminActivity.this,"Please enter all the fields",Toast.LENGTH_SHORT).show();
                }else {
                    Boolean checkPass = sqLite.checkPassword(user,pass);
                    if(checkPass == true){
                        Intent intent = new Intent(getApplicationContext(),AdminPageActivity.class);
                        startActivity(intent);
                    }else {
                        Toast.makeText(AdminActivity.this,"Invalid credentals",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        login = (Button) findViewById(R.id.buttonLogIn);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                openLogInActivity();
            }
        });

        BackToStart = (Button) findViewById(R.id.buttonBackToStartA);
        BackToStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStartActivity();
            }
        });

    }
    public void openStartActivity(){
        Intent intent = new Intent(this,StartActivity.class);
        startActivity(intent);
    }
    public void openLogInActivity(){
        Intent intent = new Intent(this,LogInActivity.class);
        startActivity(intent);
    }
}